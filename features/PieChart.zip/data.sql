CREATE TABLE IF NOT EXISTS `data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) NOT NULL,
  `gender` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `data`
--

INSERT INTO `data` (`id`, `name`, `gender`) VALUES
(1, 'Vishal Gupta', 'Male'),
(2, 'Bhaavit Gupta', 'Male'),
(3, 'Avisha Gupta', 'Female'),
(4, 'Bhaavit', 'Male'),
(5, 'Piku', 'Female'),
(6, 'Namit', 'Male'),
(7, 'Aksheeti', 'Female');
