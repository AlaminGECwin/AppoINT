
<br><br><br><br>






<footer class="bg-dark text-white  container-fluid text-center fixed-bottom  " >
  <a href="#myPage" title="To Top">
    <span class="glyphicon glyphicon-chevron-up"></span>
  </a>
  <p>Theme Made By <a href="https://www.Counselling.com" title="Visit Counselling Manager">Counselling Manager</a></p>
</footer>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="assets/js/jquery-3.3.1.slim.min.js"></script>
    <script src="assets/js/popper.min.js" ></script>
    <script src="assets/js/bootstrap.min.js" ></script>
  
  </body>
</html>