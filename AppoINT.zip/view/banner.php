<div class="" style="position: relative; text-align: center; color: white;">
<img  src="assets/logo/banner.png" width="100%" height="50" class="rounded mr-2" alt="...">
<div style="position: absolute;  top: 50%;  left: 50%;  transform: translate(-50%, -50%);"><h5 class="text-dark ">Help and resources during the COVID-19 outbreak. <a href="https://www.worldometers.info/coronavirus/#countries" target="_blank"><u class="text-dark">Learn more</u> > </a></h5></div>
</div>