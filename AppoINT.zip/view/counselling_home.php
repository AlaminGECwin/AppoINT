<div class="container">
      <h1>GEC</h1>
	  <div>
		GEC
	  </div>
</div>