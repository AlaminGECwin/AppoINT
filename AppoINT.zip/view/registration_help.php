<div class="container">
	<div class="card text-white bg-dark mb-3" >
	  <div class="card-header">Registration Help</div>
	  <div class="card-body">
	    <h5 class="card-title">Data Policy</h5>
	    <p class="card-text">This Policy describes the information we process to support AppoINT users. And we will use your information to identify you so that you can be safe.</p>
	    <h5 class="card-title">User Agreement</h5>
	    <p class="card-text">Our mission is to connect the world’s professionals to allow them to be more productive and successful. Our services are designed to promote economic opportunity for our members by enabling you and millions of other professionals to meet, exchange ideas, learn, and find opportunities or employees, work, and make decisions in a network of trusted relationships.</p>
	    <h5 class="card-title">User Registration Proccess</h5>
	    <p class="card-text">user will provide some information such as first name, email, password etc. and select user type.</p>
	  </div>
	  <div class="card-footer">
	  	<center>
	  		<a href="index.php?function=sign_up">
	  		<button type="button" class="btn btn-light">Register Now</button>
	  		</a>	
	  	</center>
	  </div>
	  

	</div>
	
</div>