<div class="container">
      <h1 class="text-center">CV</h1>
	  
		<div>
    		<center>
    		<object data="./assets/pdf/<?php echo $_GET['file'];?>" type="application/pdf" width="80%" height="1150">
    		      		  <p>আপনার ওয়েব ব্রাউজারে পিডিএফ প্লাগইন নেই।
  পরিবর্তে আপনি <a href="./assets/pdf/<?php echo $_GET['file'];?>"> এখানে ক্লিক করুন
  পিডিএফ ফাইল ডাউনলোড করুন।</a></p
    		</object>
    		</center>
    	</div>
	  
</div>