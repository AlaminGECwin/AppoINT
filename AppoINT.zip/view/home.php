
<div class="container mb-3 pb-3">
	


</div>


<div>
  


<div style="content: "";
  display: table;
  clear: both;">
  <div  style="background-color:#e9e5df; float: left;
  width: 50%;
  padding: 10px;
  height: 300px;">
    <h1 class="display-3 font-weight-bolder text-primary">Welcome to The Professional World</h1>
    <p class="lead text-success font-weight-bolder">Get your Appointment from your favorite Appointor.</p>
  </div>
  <div class="columnline" style="background-color:#bbb; float: left;
  width: 50%;
  padding: 0px;
  height: 300px;">
    <img src="assets/logo/l banner.png" height="100%" width="100%">
  </div>
</div>

</div>


