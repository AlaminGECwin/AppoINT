<?php
echo "hello php";

/*
$myfile = fopen("about.php", "w") or die("Unable to open file!");
$txt = "<?php\n";
fwrite($myfile, $txt);
$txt = 'echo "Hello about";';
fwrite($myfile, $txt);
fclose($myfile);
*/

/*
$folder="new";
mkdir($folder);
$file=$folder."/about.php";
$myfile = fopen($file, "w") or die("Unable to open file!");
$txt = "<?php\n\t";
fwrite($myfile, $txt);
$txt = 'echo "Hello new about";';
fwrite($myfile, $txt);
fclose($myfile);

*/

