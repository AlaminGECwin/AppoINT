<?php
define('EMAIL','laravel58test@gmail.com');
define('PASS','wapcac-cexxi6-fIjnyx');